========================================================

   PPTeX Installation Instructions and Release Notes
   Version: 0.3 (2006/10/31)
   Author: Ulrich Bodenhofer (ulrich@bodenhofer.com)

========================================================


The ZIP file PPTeX-0.3-packages.zip includes the following:

1. pptex.cls
2. SCCH layout: files scch.drv and scch.drvo, SCCH logo pictures
3. JKU layout: files jku.drv and jku.drvo, JKU logo pictures
4. BioInf layout: file bioinf.drv, BioInf logo picture
5. UDA layout: file uda.drv and new UDA logo picture
5. Previous UDA layout: files uda.drv and uda.drvo, old UDA logo
6. Documentation and examples


License issues:
===============

All files included in this distribution that were written by Ulrich
Bodenhofer are completely free. They may be downloaded, used, copied,
distributed, modified, without any restrictions and without the prior
acceptance of the author.

However, this distribution also contains material from other authors,
in particular, version 0.0.8f of Stephan Lehmke's TeXPower package.
For these files, license restrictions may apply. Please check the
headers of these files for further information.


Compatibility issues:
=====================

PPTex has been developed using Version 0.0.8f of Stephan Lehmke's
TeXPower package. Recent attempts to port PPTeX to the recent 0.2
version of TeXPower were not successful. The user is advised, therefore,
not to have any other version of TeXPower on his/her system except
Version 0.0.8f which is enclosed in the ZIP file pptex.zip.


Installing the files:
=====================

Unzip PPTeX-0.3-packages.zip and copy all the subfolders into a
folder where LaTeX searches for files by default (some texmf or
localtexmf directory).

Depending on the TeX distribution you use, it might be necessary to
refresh the filename database. If you use MikTeX, follow the following
steps:

1) Open the "MikTeX Settings" (2.5) or "MikTeX options" (pre-2.5) dialog
2) Go to tab "General"
4) Press "Refresh FNDB"


Testing the installation:
=========================

Your installation works if you can process one of the PPTeX demos
included in the ZIP file PPTeX-0.2-doc.zip in the doc\examples\pptex
subfolder.


Modification track:
===================

2006-10-31: Release 0.3 with new BioInf logo
2006-09-08: Release 0.2 with new UDA layout
2006-08-02: First official release 0.1
2006-06-26: Pre-release


Please report bugs to ulrich@bodenhofer.com
