========================================================

   PPTeX Installation Instructions and Release Notes
   Version: 0.1 (2006/08/02)
   Author: Ulrich Bodenhofer (ulrich@bodenhofer.com)

========================================================


The ZIP file pptex.zip includes the following:

1. pptex.cls
2. SCCH layout: files scch.drv and scch.drvo, SCCH logo pictures
3. JKU layout: files jku.drv and jku.drvo, JKU logo pictures
4. BioInf layout: file bioinf.drv, BioInf logo picture
5. UDA layout: files uda.drv and uda.drvo, UDA logo pictures
6. Documentation and examples


License issues:
===============

All files included in this distribution that were written by Ulrich
Bodenhofer are completely free. They may be downloaded, used, copied,
distributed, modified, without any restrictions and without the prior
acceptance of the author.

However, this distribution also contains material from other authors,
in particular, version 0.0.8f of Stephan Lehmke's TeXPower package.
For these files, license restrictions may apply. Please check the
headers of these files for further information.


Compatibility issues:
=====================

PPTex has been developed using Version 0.0.8f of Stephan Lehmke's
TeXPower package. Recent attempts to port PPTeX to the recent 0.2
version of TeXPower were not successful. The user is advised, therefore,
not to have any other version of TeXPower on his/her system except
Version 0.0.8f which is enclosed in the ZIP file pptex.zip.


Installing the files:
=====================

Unzip pptex.zip and copy all subfolders of the tex subdirectory into a
folder where LaTeX searches for files by default. On Windows systems
using MikTeX, the recommended path where to put the subfolders is

   ...\localtexmf\tex\latex\

Depending on the TeX distribution you use, it might be necessary to
refresh the filename database. If you use MikTeX, follow the following
steps:

1) Open the "MikteX Options" dialog
2) Select the tab "Roots"
3) Select on the localtexmf entry
4) Press "Refresh FNDB"


Testing the installation:
=========================

Your installation works if you can process one of the PPTeX demos
included in the doc\examples\pptex subfolder.


Modification track:
===================

2006-08-02: Minor bug fixes, added new layout "bioinf"
2006-06-26: Pre-release


Please report bugs to ulrich@bodenhofer.com
